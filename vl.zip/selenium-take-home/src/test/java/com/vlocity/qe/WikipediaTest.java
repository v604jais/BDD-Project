package com.vlocity.qe;

import io.github.bonigarcia.wdm.WebDriverManager;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.vlocity.qe.dataProducer;

/**
 * This class verifies elements on the wikipedia homepage.
 */
public class WikipediaTest {

    private Logger log = LoggerFactory.getLogger(WikipediaTest.class);

    private WebDriver driver;
    private ElementFinder finder;
    public List<WebElement> languagesPresent;
    public int sizes;
    public Map<Integer,String>ActualVal=new HashMap<Integer,String>();
    @BeforeClass
    public void setup() {

        /*
            If the following driver version doesn't work with your Chrome version
            see https://sites.google.com/a/chromium.org/chromedriver/downloads
            and update it as needed.
        */

        WebDriverManager.chromedriver().version("76.0.3809.126").setup();
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        finder = new ElementFinder(driver);
        driver.get("https://www.wikipedia.org/");
        driver.manage().window().maximize();
       
    }

    @Test(priority=0)
    public void sloganPresent() {

        String sloganClass = "localized-slogan";
        WebElement slogan = finder.findElement(By.className(sloganClass));

        Assert.assertNotNull(slogan, String.format("Unable to find slogan div by class: %s", sloganClass));

        log.info("Slogan text is {}", slogan.getText());

        Assert.assertEquals(slogan.getText(), "The Free Encyclopedia");
    }
    
    @Test(priority=1)
    public void langPresent() throws InterruptedException  {
    	
    	dataProducer dp=new dataProducer();
    	
    	   WebElement ribion= driver.findElement(By.xpath("//*[@id=\"js-lang-lists\"]/div[1]/ul[1]"));
    	   Thread.sleep(3000);
    	   sizes=ribion.findElements(By.tagName("li")).size();
    	   languagesPresent=ribion.findElements(By.tagName("li"));
    	   for (int i=0;i<languagesPresent.size();i++) {
    		     String av= languagesPresent.get(i).getAttribute("innerHTML")
	             .substring(languagesPresent.get(i).getAttribute("innerHTML")
	             .indexOf('>')+1, 
	             languagesPresent.get(i).getAttribute("innerHTML").lastIndexOf('<'));
    		     ActualVal.put(i, av);
    		     System.out.println(ActualVal.get(i));
    		     
    		     
    	   }
    	  
    }             
  
    
    	  	           
    
    	
    	
 

    @AfterClass
    public void closeBrowser() {

        if(driver!=null) {
            driver.close();
        }
    }
}
