package com.vlocity.qe;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class dataProducer {
	
	
	 @Test(dataProvider="DP1",dataProviderClass=dataProducer.class)
	    public String AssertingVal(String Expected) throws InterruptedException	 { 
	    	
	    
	             return Expected;
	             
	    }  
	
	@DataProvider(name = "DP1")
	public static Object[][] getDataFromDataprovider(){
        return new Object[][] { 
        	
        	{"Deutsch"},
        	{"English"},
        	{"Español"},
        	{"Français"},
        	{"Italiano"},
        	{"Nederlands"},
        	{"???"},
        	{"Polski"},
        	{"Português"},
        	{"???????"},
        	{"Sinugboanong Binisaya"},
        	{"Svenska"},
        	{"Ti?ng Vi?t"},
        	{"Winaray"},
        	{"??"}
        	
        };
           
   

    }
}
