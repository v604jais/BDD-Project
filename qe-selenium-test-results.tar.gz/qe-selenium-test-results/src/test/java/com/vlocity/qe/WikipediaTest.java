package com.vlocity.qe;

import io.github.bonigarcia.wdm.WebDriverManager;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.vlocity.qe.dataProducer;

/**
 * This class verifies elements on the wikipedia homepage.
 */
public class WikipediaTest {

    private Logger log = LoggerFactory.getLogger(WikipediaTest.class);
    private WebDriver driver;
    private ElementFinder finder;
    
    HttpURLConnection huc = null;
    int respCode = 0;
   /*public List<WebElement> languagesPresent;
    public int sizes;
    public Map<Integer,String>ActualVal=new HashMap<Integer,String>();*/
    
    @BeforeClass
    public void setup() {

        /*
            If the following driver version doesn't work with your Chrome version
            see https://sites.google.com/a/chromium.org/chromedriver/downloads
            and update it as needed.
        */

        WebDriverManager.chromedriver().version("76.0.3809.126").setup();
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        finder = new ElementFinder(driver);
        driver.get("https://www.wikipedia.org/");
        driver.manage().window().maximize();
       
    }

    @Test(enabled=false)
    public void sloganPresent() {

        String sloganClass = "localized-slogan";
        WebElement slogan = finder.findElement(By.className(sloganClass));

        Assert.assertNotNull(slogan, String.format("Unable to find slogan div by class: %s", sloganClass));

        log.info("Slogan text is {}", slogan.getText());

        Assert.assertEquals(slogan.getText(), "The Free Encyclopedia");
    }
    
    //getting all the links from the page
    @Test(enabled=false) 
    public void linksPresent() {
    	
    	List<String> hrefs = new ArrayList<String>();
    	List<WebElement> anchors = driver.findElements(By.tagName("a"));
    	for ( WebElement anchor : anchors ) {
    	    hrefs.add(anchor.getAttribute("href"));
    	}
    	System.out.println(hrefs);
    }
    //verifies the languages are present
    
    @Test(priority=1,dataProvider="DP1",dataProviderClass=dataProducer.class)
    public void langPresent(String text) throws InterruptedException  {
    	
    	 try 
    	 {
    	  boolean textToBeChecked=driver.getPageSource().contains(text);	
    	  Assert.assertTrue(textToBeChecked);
    	  log.info("Language "+ text + " is present");
    	 }
    	
    	 catch (Exception e)
    	 {
    		log.info("Language "+ text + " is not present");
    	 }
    	   
    	   
  }   	
 
    //verifies the hyper links for the Featured Languages work
    
    @Test(priority=2,dataProvider="DP1",dataProviderClass=dataProducer.class)
    public void verifyHyperLinkLang(String Linkurl) {
    	
    	 try {
             
    		    huc = (HttpURLConnection)(new URL(Linkurl).openConnection());
             
                huc.setRequestMethod("HEAD");
             
                huc.connect();
             
                respCode = huc.getResponseCode();
              
                   if(respCode==200){
            	 
            	       Assert.assertEquals(respCode, 200);
           	           log.info(Linkurl+" is up and responding 200 as statusCode ");
                     }
               
                   else{
            	 
            	       log.info(Linkurl+" is responding statusCode " +respCode); 
                      }
                 
           } catch (MalformedURLException e) {
             
             e.printStackTrace();
         }catch (IOException e) {
            
             e.printStackTrace();
         }
    	
    }
    
    

    @AfterClass
    public void closeBrowser() {

        if(driver!=null) {
            driver.close();
        }
    }
}
